<?php $__env->startSection('content'); ?>

    <div class="content-wrapper">

        <section class="content-header">

            <h1><?php echo app('translator')->getFromJson('site.dashboard'); ?></h1>

            <ol class="breadcrumb">
                <li class="active"> <?php echo app('translator')->getFromJson('site.dashboard'); ?></li>
            </ol>
        </section>

        <section class="content">



        </section><!-- end of content -->

    </div><!-- end of content wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>