<aside class="main-sidebar">

    <section class="sidebar">

        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?php echo e(asset('dashboard/img/user2-160x160.jpg')); ?>" class="img-circle" alt="User Image">
            </div>
            <div class="pull-left info">
                <p><?php echo e(auth()->user()->first_name); ?> <?php echo e(auth()->user()->last_name); ?></p>
                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <ul class="sidebar-menu" data-widget="tree">
            <li><a href="<?php echo e(route('dashboard.index')); ?>"><i class="fa fa-th"></i><span><?php echo app('translator')->getFromJson('site.dashboard'); ?></span></a></li>

            <?php if(auth()->user()->hasPermission('read_users')): ?>
              <li><a href="<?php echo e(route('dashboard.users.index')); ?>"><i class="fa fa-th"></i><span><?php echo app('translator')->getFromJson('site.users'); ?></span></a></li>
            <?php endif; ?>

            <?php if(auth()->user()->hasPermission('read_categories')): ?>
              <li><a href="<?php echo e(route('dashboard.categories.index')); ?>"><i class="fa fa-book"></i><span><?php echo app('translator')->getFromJson('site.categories'); ?></span></a></li>
            <?php endif; ?>

            
            
            
            

            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
            
        </ul>

    </section>

</aside>
